import React from 'react';
import { View, Text } from 'react-native';

const MonasterioScreen = () => {
  return (
    <View>
      <Text>Monasterio Screen</Text>
    </View>
  );
};

export default MonasterioScreen;
