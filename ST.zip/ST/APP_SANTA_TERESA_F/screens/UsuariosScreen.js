import React from 'react';
import { View, Text } from 'react-native';

const UsuariosScreen = () => {
  return (
    <View>
      <Text>Usuarios Screen</Text>
    </View>
  );
};

export default UsuariosScreen;
